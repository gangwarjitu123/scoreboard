package com.commands;

import com.Type.ResultType;
import com.Type.RunType;
import com.db.Match;
import com.db.ScoreCard;
import com.domain.Player;

public abstract class CommandExecutor {

    protected void changeStrike(ScoreCard.ScoreCardInning scoreCardInning){
        Player onStrike  = scoreCardInning.getOnStrike();
        Player nonStrike  = scoreCardInning.getNonStrike();
        scoreCardInning.setOnStrike(nonStrike);
        scoreCardInning.setNonStrike(onStrike);
    }

    protected ScoreCard.ScoreCardInning getScoreCardInning(Match match){
        return  match.getScoreCard().getScoreCardInningMap().get(match.getScoreCard().getCurrentInningType());

    }

    protected void updateBallNumberAndOver(ScoreCard.ScoreCardInning scoreCardInning,Match match){
        scoreCardInning.setCurrentBallNumber(scoreCardInning.getCurrentBallNumber()+1);
        if(scoreCardInning.getCurrentBallNumber()==6){
            scoreCardInning.setCurrentBallNumber(0);
            scoreCardInning.setTotalOver(scoreCardInning.getTotalOver()+1);
            changeStrike(scoreCardInning);
        }
        if(match.getNumberOfOver()==scoreCardInning.getTotalOver() && !match.getScoreCard().isFirstInningCompleted()){
            match.getScoreCard().setFirstInningCompleted(true);
            scoreCardInning.setInningStatus("completed");
        }else if(match.getNumberOfOver()==scoreCardInning.getTotalOver()){
            match.getScoreCard().setSecondInningCompleted(true);
            scoreCardInning.setInningStatus("completed");
            match.setMatchCompleted(true);
            match.setResultType(ResultType.FINISHED);
            updateWinner(match);
        }
    }

    protected  void updateWinner(Match match){
        ScoreCard.ScoreCardInning scoreCardInningFirst = match.getScoreCard().getScoreCardInningMap().get(ScoreCard.InningType.FIRST);
        ScoreCard.ScoreCardInning scoreCardInningSecond = match.getScoreCard().getScoreCardInningMap().get(ScoreCard.InningType.SECOND);
        int totalScoreFirst  =  scoreCardInningFirst.getTotalRun();
        int  totalScoreSecond = scoreCardInningSecond.getTotalRun();
        String firstTeam = match.getScoreCard().getInningTypeVsTeamName().get(ScoreCard.InningType.FIRST);
        String secondTeam = match.getScoreCard().getInningTypeVsTeamName().get(ScoreCard.InningType.SECOND);
        if(totalScoreFirst  >totalScoreSecond){
            int winnerRun = totalScoreFirst - totalScoreSecond;
            match.setWinByRun(winnerRun);
            match.setWinnerTeam(firstTeam);
            match.setResultType(ResultType.FINISHED);
        }else if(totalScoreFirst <totalScoreSecond){
            int winnerRun = totalScoreSecond- totalScoreFirst;
            match.setWinByRun(winnerRun);
            match.setWinnerTeam(secondTeam);
            match.setResultType(ResultType.FINISHED);
        }else {
            match.setResultType(ResultType.TIE);
        }



    }


    public abstract void execute(String ballMetaData,Match match);
}
