package com.Type;


public enum PlayerType {
    BATSMAN,
    BOWLER,
    ALLROUNDER
}
