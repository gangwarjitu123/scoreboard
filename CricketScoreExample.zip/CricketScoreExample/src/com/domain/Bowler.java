package com.domain;

import com.Type.PlayerType;

public class Bowler extends Player {

    public Bowler(PlayerType playerMainType) {
        super(playerMainType);
    }
}
