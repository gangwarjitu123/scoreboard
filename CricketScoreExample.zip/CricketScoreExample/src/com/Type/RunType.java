package com.Type;

public enum RunType {
    NORMAL,
    FOUR,
    SIX,
    LEG_BYE,
    BYE,
    WIDE,
    NO_BALL,
    OVER_THROW

}
