package com;


import com.Utils.KeyUtils;
import com.dao.Impl.MatchServiceDaoImpl;
import com.request.MatchCreateRequest;
import com.service.Impl.MatchServiceImpl;
import com.service.MatchService;

import java.util.Arrays;


public class Driver {

    public static void main(String[] args){
       TestUtils.createMatch_One();
       TestUtils.createMatch_Two();

    }

}
