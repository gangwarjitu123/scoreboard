package com.domain;

import com.Type.BallType;

public class Over {
    private int number;
    private BallType ballType;
    private Ball ball;
    private Player bowledBy;

}
