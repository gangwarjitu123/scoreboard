package com.Utils;

public class KeyUtils {
    public static String createMatchKey(String firstTeam, String secondTeam){
        return firstTeam+":"+secondTeam;
    }
}
