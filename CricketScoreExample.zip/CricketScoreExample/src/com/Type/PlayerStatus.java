package com.Type;

public enum PlayerStatus {
    OUT,NOTOUT,BATTING,BENCH
}
