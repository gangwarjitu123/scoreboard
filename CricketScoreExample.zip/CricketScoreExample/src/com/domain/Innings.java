package com.domain;

import java.util.List;

public class Innings {
    private String teamName;
    private Integer extra;
    private Integer totalScore;
    private Integer over;

    private List<Player> player;
}
