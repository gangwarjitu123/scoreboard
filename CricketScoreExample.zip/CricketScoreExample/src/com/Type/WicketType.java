package com.Type;

public enum WicketType {
    BOLD,
    CAUGHT,
    STUMPED,
    RUN_OUT,
    HIT_WICKET,
    LWB
}
