package com.domain;


import com.Type.PlayerType;

public class BatsMan  extends Player {
    public BatsMan(PlayerType playerMainType) {
        super(playerMainType);
    }



}
