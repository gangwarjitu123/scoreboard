package com.Type;

public enum ResultType {
    TIE,
    FINISHED,
    LIVE
}
