package com.Type;

public enum BallType {
    NORMAL,WIDE,WICKET,NO_BALL
}
