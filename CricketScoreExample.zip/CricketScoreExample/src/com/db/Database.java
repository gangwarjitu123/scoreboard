package com.db;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class Database {
 public static Map<String, Match> matchMap = new HashMap<>();

}
